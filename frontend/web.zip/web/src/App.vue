<script setup>
import Navbar from './views/Navbar.vue';
</script>

<template>
  <Navbar />
  <RouterView />
</template>

<style scoped>
/* Add your global styles here */
</style>